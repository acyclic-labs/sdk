# @acyclic-labs/harness changelog

## 0.2.0 - Unreleased

- Align the unified SDK candidate and Objects content adapter with the breaking Objects v2 public package transition.

## Unreleased

- Migrate the Objects content adapter to logical v2 bucket/key storage, canonical content identities and bounded byte verification.
- Bind stable upload operations before content publication, including duplicate content, without relying on public Object versions.

## 0.1.5 - 2026-09-25

- Aligns the client and transport adapters with the qualified SDK 0.1.5 release.

## 0.1.4 - 2026-09-25

- Aligns the client and transport adapters with the qualified SDK 0.1.4 release.

## 0.1.3 - 2026-09-25

- Aligns the client and transport adapters with the qualified SDK 0.1.3 source.

## 0.1.2 - 2026-09-25

- Aligns the client runtime and transport adapters with the 0.1.2 SDK release.

## 0.1.1 - 2026-09-24

- First coordinated SDK release of the framework-neutral agent-runtime client.
- Includes typed aggregate handles, replay-aware cursors, bounded hydration,
  offline outbox support, and embedded, JSONL, WebSocket, HTTP-SSE, and gRPC
  transport adapters.
