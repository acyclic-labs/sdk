/* @ts-self-types="./acyclic_harness_wasm.d.ts" */

/**
 * Bounded Rust-owned content state for the WASM `MemoryConversation` adapter.
 * The native filesystem provider uses the same crate-level core while
 * retaining its signed provider-generation proof around delegated reads.
 */
export class WasmContentStore {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmContentStoreFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmcontentstore_free(ptr, 0);
    }
    /**
     * Returns the current path generation as an exact JavaScript bigint.
     * @returns {any}
     */
    generation() {
        const ret = wasm.wasmcontentstore_generation(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Tests local residency without exposing mutable storage maps.
     * @param {any} file
     * @returns {boolean}
     */
    has(file) {
        const ret = wasm.wasmcontentstore_has(this.__wbg_ptr, file);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Returns a generation-pinned directory page from Rust-owned path state.
     * @param {string} path
     * @param {any} generation
     * @param {string | null | undefined} after
     * @param {number} maximum
     * @returns {any}
     */
    list(path, generation, after, maximum) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(after) ? 0 : passStringToWasm0(after, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmcontentstore_list(this.__wbg_ptr, ptr0, len0, generation, ptr1, len1, maximum);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {any} volume
     * @param {number} maximum_file_bytes
     * @param {number} maximum_path_bytes
     * @param {number} maximum_resident_bytes
     * @param {number} maximum_resident_files
     */
    constructor(volume, maximum_file_bytes, maximum_path_bytes, maximum_resident_bytes, maximum_resident_files) {
        const ret = wasm.wasmcontentstore_new(volume, maximum_file_bytes, maximum_path_bytes, maximum_resident_bytes, maximum_resident_files);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmContentStoreFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Reports whether a new file at `path` would conflict with a file or
     * directory already retained by this provider.
     * @param {string} path
     * @returns {boolean}
     */
    pathConflicts(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmcontentstore_pathConflicts(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * Reads only an exact, resident immutable reference owned by this store.
     * @param {any} file
     * @returns {Uint8Array}
     */
    read(file) {
        const ret = wasm.wasmcontentstore_read(this.__wbg_ptr, file);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Resolves a path at or before an explicit generation.
     * @param {string} path
     * @param {any} generation
     * @returns {any}
     */
    read_path(path, generation) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmcontentstore_read_path(this.__wbg_ptr, ptr0, len0, generation);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Stores one immutable file and optionally advances its path head.
     * @param {string} path
     * @param {Uint8Array} bytes
     * @param {string} media_type
     * @param {string} display_name
     * @param {boolean} update_path
     * @returns {any}
     */
    stage(path, bytes, media_type, display_name, update_path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(media_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(display_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.wasmcontentstore_stage(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, update_path);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) WasmContentStore.prototype[Symbol.dispose] = WasmContentStore.prototype.free;

/**
 * Opaque synchronous reducer hosted in WebAssembly.
 */
export class WasmReducer {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmReducer.prototype);
        obj.__wbg_ptr = ptr;
        WasmReducerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmReducerFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmreducer_free(ptr, 0);
    }
    /**
     * Applies a deterministic command. Fresh extension migrations require the
     * native content-admission host and cannot be synthesized by this reducer.
     * @param {any} command
     * @returns {any}
     */
    apply(command) {
        const ret = wasm.wasmreducer_apply(this.__wbg_ptr, command);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Applies one canonical Protobuf command, excluding fresh migrations
     * that require executable content admission, and returns a response.
     * @param {Uint8Array} command
     * @returns {Uint8Array}
     */
    applyWire(command) {
        const ptr0 = passArray8ToWasm0(command, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_applyWire(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * Attenuates a scope without permitting capability expansion.
     * @param {any} parent
     * @param {string} id
     * @param {any} capabilities
     * @returns {any}
     */
    attenuate(parent, id, capabilities) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_attenuate(this.__wbg_ptr, parent, ptr0, len0, capabilities);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Returns the authoritative conversation projection, never a parallel JS reducer.
     * @returns {string}
     */
    conversationJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmreducer_conversationJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Returns the same bounded page with Rust-owned JS integer projection:
     * revisions and cursors stay `BigInt`, validated file lengths become Number.
     * @param {bigint} after_sequence
     * @param {number} limit
     * @returns {any}
     */
    conversationPage(after_sequence, limit) {
        const ret = wasm.wasmreducer_conversationPage(this.__wbg_ptr, after_sequence, limit);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Returns an immutable, bounded page of canonical conversation records.
     * `after_sequence` is an exclusive cursor in the message sequence, not
     * the potentially larger aggregate event revision.
     * @param {bigint} after_sequence
     * @param {number} limit
     * @returns {string}
     */
    conversationPageJson(after_sequence, limit) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmreducer_conversationPageJson(this.__wbg_ptr, after_sequence, limit);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Resolves a complete canonical attachment manifest under the Rust rules.
     * @param {any} manifest
     * @param {Uint8Array} bytes
     * @param {number} item_count
     * @returns {any}
     */
    decodeAttachmentManifest(manifest, bytes, item_count) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_decodeAttachmentManifest(this.__wbg_ptr, manifest, ptr0, len0, item_count);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Delegates a segment-bounded private directory to a reader without a fork.
     * @param {any} owner_scope
     * @param {string} reader
     * @param {string} id
     * @param {any} volume
     * @param {string} prefix
     * @returns {any}
     */
    delegatePrivateDirectoryRead(owner_scope, reader, id, volume, prefix) {
        const ptr0 = passStringToWasm0(reader, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(prefix, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_delegatePrivateDirectoryRead(this.__wbg_ptr, owner_scope, ptr0, len0, ptr1, len1, volume, ptr2, len2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Delegates one pinned private file from its signed owner to a reader.
     * @param {any} owner_scope
     * @param {string} reader
     * @param {string} id
     * @param {any} file
     * @returns {any}
     */
    delegatePrivateFileRead(owner_scope, reader, id, file) {
        const ptr0 = passStringToWasm0(reader, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_delegatePrivateFileRead(this.__wbg_ptr, owner_scope, ptr0, len0, ptr1, len1, file);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Computes the canonical capability for one private directory boundary.
     * @param {any} volume
     * @param {string} prefix
     * @returns {string}
     */
    directoryReadCapability(volume, prefix) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(prefix, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.wasmreducer_directoryReadCapability(this.__wbg_ptr, volume, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Derives the canonical SHA-256 descriptor for staged bytes.
     * @param {Uint8Array} bytes
     * @param {string} media_type
     * @returns {string}
     */
    fileDescriptorJson(bytes, media_type) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(media_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.wasmreducer_fileDescriptorJson(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Computes the exact-version read capability without embedding it in a ref.
     * @param {any} file
     * @returns {string}
     */
    fileReadCapability(file) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmreducer_fileReadCapability(this.__wbg_ptr, file);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Issues a root scope from this host's explicit authority object.
     * @param {string} id
     * @param {any} capabilities
     * @returns {any}
     */
    issueScope(id, capabilities) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_issueScope(this.__wbg_ptr, ptr0, len0, capabilities);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Issues a root scope signed for one acting agent.
     * @param {string} agent
     * @param {string} id
     * @param {any} capabilities
     * @returns {any}
     */
    issueScopeForAgent(agent, id, capabilities) {
        const ptr0 = passStringToWasm0(agent, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_issueScopeForAgent(this.__wbg_ptr, ptr0, len0, ptr1, len1, capabilities);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Resolves named policy layers and issues only their effective grant.
     * @param {string} id
     * @param {any} layers
     * @returns {any}
     */
    issueScopeWithPolicies(id, layers) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_issueScopeWithPolicies(this.__wbg_ptr, ptr0, len0, layers);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Resolves hierarchy policy and binds its result to one acting agent.
     * @param {string} agent
     * @param {string} id
     * @param {any} layers
     * @returns {any}
     */
    issueScopeWithPoliciesForAgent(agent, id, layers) {
        const ptr0 = passStringToWasm0(agent, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_issueScopeWithPoliciesForAgent(this.__wbg_ptr, ptr0, len0, ptr1, len1, layers);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Creates an empty reducer with explicit host-managed authority.
     * @param {any} authority
     * @param {string} issuer_id
     * @param {Uint8Array} issuer_key
     * @param {any} schemas
     */
    constructor(authority, issuer_id, issuer_key, schemas) {
        const ptr0 = passStringToWasm0(issuer_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(issuer_key, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_new(authority, ptr0, len0, ptr1, len1, schemas);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmReducerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Returns the exact wire identity used by this compiled core.
     * @returns {any}
     */
    protocolIdentity() {
        const ret = wasm.wasmreducer_protocolIdentity(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Restores a snapshot under explicit host-managed authority.
     * @param {any} snapshot
     * @param {string} issuer_id
     * @param {Uint8Array} issuer_key
     * @param {any} schemas
     * @returns {WasmReducer}
     */
    static restore(snapshot, issuer_id, issuer_key, schemas) {
        const ptr0 = passStringToWasm0(issuer_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(issuer_key, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_restore(snapshot, ptr0, len0, ptr1, len1, schemas);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmReducer.__wrap(ret[0]);
    }
    /**
     * Returns a versioned integrity-checked restoration snapshot.
     * @returns {any}
     */
    snapshot() {
        const ret = wasm.wasmreducer_snapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Validates one ref-only canonical message under explicit runtime limits.
     * @param {any} message
     * @param {any} limits
     */
    validateConversationMessage(message, limits) {
        const ret = wasm.wasmreducer_validateConversationMessage(this.__wbg_ptr, message, limits);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Validates an exact content reference using the native Rust contract.
     * @param {any} file
     */
    validateFileRef(file) {
        const ret = wasm.wasmreducer_validateFileRef(this.__wbg_ptr, file);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Applies configured runtime bounds to one exact file reference.
     * @param {any} file
     * @param {any} limits
     */
    validateFileUnderLimits(file, limits) {
        const ret = wasm.wasmreducer_validateFileUnderLimits(this.__wbg_ptr, file, limits);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Authenticates an owner-issued read grant for this exact immutable file.
     * A caller-supplied capability string alone is never accepted as proof.
     * @param {any} scope
     * @param {any} file
     */
    verifyContentRead(scope, file) {
        const ret = wasm.wasmreducer_verifyContentRead(this.__wbg_ptr, scope, file);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Authenticates a writer against the original private-volume owner.
     * @param {any} scope
     * @param {any} volume
     */
    verifyContentWrite(scope, volume) {
        const ret = wasm.wasmreducer_verifyContentWrite(this.__wbg_ptr, scope, volume);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Verifies exact bytes against the pinned SHA-256 and byte-length descriptor.
     * @param {any} file
     * @param {Uint8Array} bytes
     */
    verifyFileBytes(file, bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_verifyFileBytes(this.__wbg_ptr, file, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Authenticates lazy directory and named-path access against the
     * owner's signed, segment-bounded private-volume read grant.
     * @param {any} scope
     * @param {any} volume
     * @param {string} granted_prefix
     * @param {string} path
     */
    verifyPrivateDirectoryRead(scope, volume, granted_prefix, path) {
        const ptr0 = passStringToWasm0(granted_prefix, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmreducer_verifyPrivateDirectoryRead(this.__wbg_ptr, scope, volume, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Authenticates the signed scope before provider discovery or routing.
     * @param {any} scope
     */
    verifyScope(scope) {
        const ret = wasm.wasmreducer_verifyScope(this.__wbg_ptr, scope);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Computes the canonical Rust capability for one validated volume operation.
     * @param {any} volume
     * @param {string} operation
     * @returns {string}
     */
    volumeCapability(volume, operation) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(operation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.wasmreducer_volumeCapability(this.__wbg_ptr, volume, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Stable physical namespace shared by Filesystem and Objects adapters.
     * @param {any} volume
     * @returns {string}
     */
    volumeStorageName(volume) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmreducer_volumeStorageName(this.__wbg_ptr, volume);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
}
if (Symbol.dispose) WasmReducer.prototype[Symbol.dispose] = WasmReducer.prototype.free;

/**
 * Builds and validates the complete immutable batch request before any
 * member admission. Inputs, task identity, limits, policy, and route are
 * projected by the same Rust constructor used by native hosts.
 * @param {WasmBatchAdmissionInput} value
 * @returns {WasmDurableBatchWire}
 */
export function admitBatch(value) {
    const ret = wasm.admitBatch(value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Builds the complete SDK-facing durable batch request in one Rust-owned
 * projection. Member envelopes, policy, implementation digest, canonical
 * manifest, and request digest all derive from the same validated request.
 * @param {WasmBatchAdmissionInput} value
 * @returns {WasmBatchAdmissionRequest}
 */
export function admitBatchRequest(value) {
    const ret = wasm.admitBatchRequest(value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Admits one provider model event with the native stream rules and returns
 * the detached state needed for the next event. Text accounting is cumulative
 * across model steps while event and tool-call bounds reset at each step.
 * @param {WasmModelEventInput} event
 * @param {WasmModelLimitsInput} limits
 * @param {WasmModelEventAdmissionState | null} state
 * @returns {WasmModelEventAdmission}
 */
export function admitModelEvent(event, limits, state) {
    const ret = wasm.admitModelEvent(event, limits, state);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Builds and validates the complete owner-retained task admission envelope.
 * TypeScript supplies public values, while Rust owns identity derivation,
 * schema/value validation, limits, authority, and execution binding.
 * @param {WasmTaskAdmissionInput} value
 * @returns {WasmTaskAdmissionWire}
 */
export function admitTask(value) {
    const ret = wasm.admitTask(value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Derives the same immutable per-slot operation as Rust durable admission.
 * @param {string} group
 * @param {string} batch
 * @param {number} index
 * @returns {string}
 */
export function batchMemberOperationId(group, batch, index) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(group, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(batch, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.batchMemberOperationId(ptr0, len0, ptr1, len1, index);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Decodes a generated aggregate kind using the native enum mapping.
 * @param {number} value
 * @returns {any}
 */
export function decodeAggregateKind(value) {
    const ret = wasm.decodeAggregateKind(value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decodes and validates a canonical Protobuf apply response using Rust-owned
 * event, authority, scope, digest, and payload rules.
 * @param {Uint8Array} bytes
 * @returns {any}
 */
export function decodeApplyResponse(bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeApplyResponse(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decodes a complete canonical attachment list without a reducer instance.
 * @param {any} manifest
 * @param {Uint8Array} bytes
 * @param {number} item_count
 * @returns {any}
 */
export function decodeAttachmentManifest(manifest, bytes, item_count) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeAttachmentManifest(manifest, ptr0, len0, item_count);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Parses canonical JSON without passing full-width integer literals through
 * JavaScript Number. Large serde integers are returned as `BigInt`.
 * @param {Uint8Array} bytes
 * @returns {any}
 */
export function decodeCanonicalJson(bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeCanonicalJson(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decodes one canonical event payload using the native event union.
 * @param {string} event_type
 * @param {Uint8Array} canonical_payload_json
 * @returns {any}
 */
export function decodeEventPayload(event_type, canonical_payload_json) {
    const ptr0 = passStringToWasm0(event_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(canonical_payload_json, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.decodeEventPayload(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Parses external JSON with exact integers but without demanding canonical
 * key order or whitespace. Callers must still apply their schema and numeric
 * range policy before presenting model-authored values to an executor.
 * @param {Uint8Array} bytes
 * @returns {any}
 */
export function decodeJson(bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeJson(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Derives a stable child operation/message identity from one admitted operation
 * and a local role label without duplicating UUID bit manipulation in hosts.
 * @param {string} operation
 * @param {string} label
 * @returns {string}
 */
export function deriveOperationUuid(operation, label) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(operation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.deriveOperationUuid(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Hashes the same bounded canonical JSON bytes used by native admissions.
 * @param {any} value
 * @returns {Uint8Array}
 */
export function digestCanonicalJson(value) {
    const ret = wasm.digestCanonicalJson(value);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v1;
}

/**
 * Encodes a validated attachment list in the exact typed manifest wire form.
 * @param {any} items
 * @returns {Uint8Array}
 */
export function encodeAttachmentManifest(items) {
    const ret = wasm.encodeAttachmentManifest(items);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v1;
}

/**
 * Serializes a plain JavaScript data value through Rust's canonical JSON
 * representation. Unsafe integer Numbers are rejected before conversion;
 * callers must supply `BigInt` for exact full-width identities and counters.
 * @param {any} value
 * @returns {Uint8Array}
 */
export function encodeCanonicalJson(value) {
    const ret = wasm.encodeCanonicalJson(value);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v1;
}

/**
 * Stages a descriptor with Rust-owned SHA-256, media-type, and safe
 * byte-length rules, projecting its bounded length as a JS Number.
 * @param {Uint8Array} bytes
 * @param {string} media_type
 * @returns {any}
 */
export function fileDescriptor(bytes, media_type) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(media_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.fileDescriptor(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Converts a fully captured report into its canonical publishable child seed.
 * @param {any} report
 * @returns {any}
 */
export function forkSeedFromReport(report) {
    const ret = wasm.forkSeedFromReport(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Plans one deterministic conversation turn before any model or content
 * callback runs.  The reducer state and payload checks are shared with the
 * native filesystem memory host; JavaScript retains ownership of asynchronous
 * reads and model dispatch after this plan is committed.
 * @param {any} conversation
 * @param {string} operation_id
 * @param {any} content
 * @param {any} attachments
 * @param {any} limits
 * @param {any} existing_selection
 * @param {boolean} has_completed_output
 * @param {boolean} can_reconcile
 * @returns {WasmTurnPreparation}
 */
export function prepareConversationTurn(conversation, operation_id, content, attachments, limits, existing_selection, has_completed_output, can_reconcile) {
    const ptr0 = passStringToWasm0(operation_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.prepareConversationTurn(conversation, ptr0, len0, content, attachments, limits, existing_selection, has_completed_output, can_reconcile);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Runs the canonical Rust conversation projection over bytes captured by the
 * owner.  TypeScript supplies a map rather than a callback so authorization
 * and async reads finish before this deterministic core is entered.
 * @param {any} conversation
 * @param {any} selection
 * @param {any} files
 * @param {number} maximum_messages
 * @param {number} maximum_attachments
 * @param {number} maximum_render_bytes
 * @param {number} maximum_projected_attachments
 * @returns {Promise<any>}
 */
export function selectModelContext(conversation, selection, files, maximum_messages, maximum_attachments, maximum_render_bytes, maximum_projected_attachments) {
    const ret = wasm.selectModelContext(conversation, selection, files, maximum_messages, maximum_attachments, maximum_render_bytes, maximum_projected_attachments);
    return ret;
}

/**
 * Derives the exact task and machine identities retained by durable
 * admission. The digest envelope and resumable machine pin are shared with
 * native Rust registration.
 * @param {WasmTaskIdentityInput} value
 * @returns {WasmTaskAdmissionIdentities}
 */
export function taskAdmissionIdentities(value) {
    const ret = wasm.taskAdmissionIdentities(value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Derives the same pinned task registration digest used by native admission.
 * @param {string} name
 * @param {string} version
 * @param {any} input_schema
 * @param {any} output_schema
 * @param {any} requirements
 * @param {Uint8Array} machine_digest
 * @returns {Uint8Array}
 */
export function taskIdentityDigest(name, version, input_schema, output_schema, requirements, machine_digest) {
    const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(version, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passArray8ToWasm0(machine_digest, wasm.__wbindgen_malloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.taskIdentityDigest(ptr0, len0, ptr1, len1, input_schema, output_schema, requirements, ptr2, len2);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v4 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v4;
}

/**
 * Uses one half of a canonical action digest as a stable local identity.
 * The digest is already SHA-256; the two halves separate approval operations
 * from their interaction tickets without a second hashing convention.
 * @param {Uint8Array} digest
 * @param {boolean} second
 * @returns {string}
 */
export function uuidFromDigestHalf(digest, second) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(digest, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.uuidFromDigestHalf(ptr0, len0, second);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Pure v2 contract admission shared by native and JavaScript hosts. The
 * returned object is detached and canonically shaped by Rust serde; context
 * supplies `Limits` for messages and the open ticket for resolutions.
 * @param {string} kind
 * @param {any} value
 * @param {any} context
 * @returns {any}
 */
export function validateContract(kind, value, context) {
    const ptr0 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateContract(ptr0, len0, value, context);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the one Rust UUID spelling accepted for a conversation identity.
 * @param {string} value
 * @returns {string}
 */
export function validateConversationMessageId(value) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.validateConversationMessageId(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Parses one public Harness identity with the canonical Rust contract and
 * returns its normalized UUID spelling for a branded TypeScript facade.
 * @param {string} kind
 * @param {string} value
 * @returns {string}
 */
export function validateIdentity(kind, value) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.validateIdentity(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Validates provider-neutral model content under the exact native limits.
 * @param {WasmModelContentInput} content
 * @param {WasmModelLimitsInput} limits
 */
export function validateModelContent(content, limits) {
    const ret = wasm.validateModelContent(content, limits);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates selection order and tool linkage before the host resolves any
 * owner-mediated file bytes.
 * @param {any} conversation
 * @param {any} selection
 */
export function validateModelContextSelection(conversation, selection) {
    const ret = wasm.validateModelContextSelection(conversation, selection);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates a complete provider-neutral model message list with the native
 * role, message-count, and content bounds.  Context builders and the stock
 * TypeScript loop therefore share the same closed role set and limits as
 * native durable execution.
 * @param {readonly WasmModelMessageInput[]} messages
 * @param {WasmModelLimitsInput} limits
 */
export function validateModelMessages(messages, limits) {
    const ret = wasm.validateModelMessages(messages, limits);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Admits an already projected, provider-proven context with native model bounds.
 * @param {any} selected
 * @param {any} limits
 */
export function validateSelectedModelContext(selected, limits) {
    const ret = wasm.validateSelectedModelContext(selected, limits);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates and reprojects one owner-retained direct-child page using the
 * same bounds and bytewise slot ordering as native Harness hosts.
 * @param {WasmTaskChildrenPageInput} value
 * @returns {WasmTaskChildrenPage}
 */
export function validateTaskChildrenPage(value) {
    const ret = wasm.validateTaskChildrenPage(value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Validates the exact task dependency graph used by the TypeScript builder.
 * The input is a contract projection only; no executable task handlers cross
 * the WASM boundary and Rust owns graph traversal, revision matching, grants,
 * and extension requirement admission.
 * @param {WasmTaskDependencyInput} value
 */
export function validateTaskRequirements(value) {
    const ret = wasm.validateTaskRequirements(value);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates a model-visible tool definition using the native contract.
 * @param {any} definition
 */
export function validateToolDefinition(definition) {
    const ret = wasm.validateToolDefinition(definition);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates one tool invocation against its registered definition.
 * @param {any} definition
 * @param {any} invocation
 */
export function validateToolInvocation(definition, invocation) {
    const ret = wasm.validateToolInvocation(definition, invocation);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates one successful tool result against its registered definition.
 * @param {any} definition
 * @param {any} result
 */
export function validateToolResult(definition, result) {
    const ret = wasm.validateToolResult(definition, result);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Applies the same JSON Schema admission used by Rust tool execution before
 * a TypeScript facade turns an untrusted model value into a typed argument.
 * @param {any} schema
 * @param {any} value
 * @returns {any}
 */
export function validateToolValue(schema, value) {
    const ret = wasm.validateToolValue(schema, value);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Validates one human-authored model input using the native content rules.
 * @param {WasmModelContentInput} content
 */
export function validateUserInput(content) {
    const ret = wasm.validateUserInput(content);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Validates a protobuf admission identity; returns encoded `Error` bytes, or empty on success.
 * @param {Uint8Array} command
 * @param {Uint8Array} admission
 * @returns {Uint8Array}
 */
export function validateWireAdmission(command, admission) {
    const ptr0 = passArray8ToWasm0(command, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(admission, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireAdmission(ptr0, len0, ptr1, len1);
    var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v3;
}

/**
 * Validates a protobuf cancel request using the canonical Rust scope rules.
 * @param {Uint8Array} request
 * @returns {Uint8Array}
 */
export function validateWireCancel(request) {
    const ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireCancel(ptr0, len0);
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}

/**
 * Validates a protobuf cancellation identity; returns encoded `Error` bytes, or empty on success.
 * @param {Uint8Array} request
 * @param {Uint8Array} response
 * @returns {Uint8Array}
 */
export function validateWireCancellation(request, response) {
    const ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(response, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireCancellation(ptr0, len0, ptr1, len1);
    var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v3;
}

/**
 * Validates one complete protobuf command before it crosses a wire adapter.
 * @param {Uint8Array} command
 * @returns {Uint8Array}
 */
export function validateWireCommand(command) {
    const ptr0 = passArray8ToWasm0(command, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireCommand(ptr0, len0);
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}

/**
 * Validates only the protocol identity of a command envelope.
 * @param {Uint8Array} command
 * @returns {Uint8Array}
 */
export function validateWireCommandProtocol(command) {
    const ptr0 = passArray8ToWasm0(command, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireCommandProtocol(ptr0, len0);
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}

/**
 * Validates a protobuf handshake; returns encoded `Error` bytes, or empty on success.
 * @param {Uint8Array} request
 * @param {Uint8Array} response
 * @returns {Uint8Array}
 */
export function validateWireHandshake(request, response) {
    const ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(response, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireHandshake(ptr0, len0, ptr1, len1);
    var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v3;
}

/**
 * Validates a protobuf observe request using the canonical Rust scope rules.
 * @param {Uint8Array} request
 * @returns {Uint8Array}
 */
export function validateWireObserve(request) {
    const ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireObserve(ptr0, len0);
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}

/**
 * Validates a protobuf replay request against the compiled protocol identity.
 * @param {Uint8Array} request
 * @returns {Uint8Array}
 */
export function validateWireResume(request) {
    const ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireResume(ptr0, len0);
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}

/**
 * Validates a protobuf operation status identity; returns encoded `Error` bytes, or empty on success.
 * @param {Uint8Array} request
 * @param {Uint8Array} status
 * @returns {Uint8Array}
 */
export function validateWireStatus(request, status) {
    const ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(status, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.validateWireStatus(ptr0, len0, ptr1, len1);
    var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v3;
}

/**
 * Checks immutable file identity without constructing a reducer or issuer.
 * @param {any} file
 * @param {Uint8Array} bytes
 */
export function verifyFileBytes(file, bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.verifyFileBytes(file, ptr0, len0);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_2e59b1b37a9a34c3: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_e6ffdb596c888833: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_boolean_get_a86c216575a75c30: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_is_bigint_6c98f7e945dacdde: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_49868bde5eb1e745: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_344c8750a8525473: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_40c5a80572e8f9d3: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_b29b5c5a8065ba1a: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_c0cca72b82b86f4d: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_number_get_7579aab02a8a620c: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_914df97fcfa788f2: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_81fc77679af83bc6: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_3c3b4f651835fbcb: function(arg0) {
            arg0._wbg_cb_unref();
        },
        __wbg_call_d578befcc3145dee: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_forEach_5838a63302d6ed43: function(arg0, arg1, arg2) {
            try {
                var state0 = {a: arg1, b: arg2};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined_______true_(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                arg0.forEach(cb0);
            } finally {
                state0.a = 0;
            }
        },
        __wbg_from_741da0f916ab74aa: function(arg0) {
            const ret = Array.from(arg0);
            return ret;
        },
        __wbg_getPrototypeOf_3a1ab0101ee3242c: function(arg0) {
            const ret = Object.getPrototypeOf(arg0);
            return ret;
        },
        __wbg_getRandomValues_3f44b700395062e5: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_get_9ce57b3c923f4f1a: function(arg0, arg1) {
            const ret = arg0.get(arg1);
            return ret;
        },
        __wbg_get_f96702c6245e4ef9: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_unchecked_7d7babe32e9e6a54: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_instanceof_Map_a10a2795ef4bfe97: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_4b8da683deb25d72: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_db61795ad004c139: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_is_3ce118e1fc3aa47e: function(arg0, arg1) {
            const ret = Object.is(arg0, arg1);
            return ret;
        },
        __wbg_keys_e611eeb7873788db: function(arg0) {
            const ret = Object.keys(arg0);
            return ret;
        },
        __wbg_length_0c32cb8543c8e4c8: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_6e821edde497a532: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_new_4f9fafbb3909af72: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_99cabae501c0a8a0: function() {
            const ret = new Map();
            return ret;
        },
        __wbg_new_a560378ea1240b14: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_f3c9df4f38f3f798: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_typed_14d7cc391ce53d2c: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined_______true__86(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_prototypesetcall_3e05eb9545565046: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_queueMicrotask_abaf92f0bd4e80a4: function(arg0) {
            const ret = arg0.queueMicrotask;
            return ret;
        },
        __wbg_queueMicrotask_df5a6dac26d818f3: function(arg0) {
            queueMicrotask(arg0);
        },
        __wbg_resolve_0a79de24e9d2267b: function(arg0) {
            const ret = Promise.resolve(arg0);
            return ret;
        },
        __wbg_set_08463b1df38a7e29: function(arg0, arg1, arg2) {
            const ret = arg0.set(arg1, arg2);
            return ret;
        },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_set_6c60b2e8ad0e9383: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_8ee2d34facb8466e: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_static_accessor_GLOBAL_THIS_a1248013d790bf5f: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_f2e0f995a21329ff: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_24f78b6d23f286ea: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_59fd959c540fe405: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_then_a0c8db0381c8994c: function(arg0, arg1) {
            const ret = arg0.then(arg1);
            return ret;
        },
        __wbg_toString_482811163a3a0909: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.toString(arg1);
            return ret;
        }, arguments); },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 2055, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___wasm_bindgen_6f077bfab82c36f___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_6f077bfab82c36f___JsError___true_);
            return ret;
        },
        __wbindgen_cast_0000000000000002: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000003: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_0000000000000005: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./acyclic_harness_wasm_bg.js": import0,
    };
}

function wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___wasm_bindgen_6f077bfab82c36f___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_6f077bfab82c36f___JsError___true_(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___wasm_bindgen_6f077bfab82c36f___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_6f077bfab82c36f___JsError___true_(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined_______true_(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined_______true_(arg0, arg1, arg2, arg3);
}

function wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined_______true__86(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen_6f077bfab82c36f___convert__closures_____invoke___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined___js_sys_87d5cc57c0d6a05f___Function_fn_wasm_bindgen_6f077bfab82c36f___JsValue_____wasm_bindgen_6f077bfab82c36f___sys__Undefined_______true__86(arg0, arg1, arg2, arg3);
}

const WasmContentStoreFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmcontentstore_free(ptr >>> 0, 1));
const WasmReducerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmreducer_free(ptr >>> 0, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_destroy_closure(state.a, state.b));

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasm;
function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('acyclic_harness_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
