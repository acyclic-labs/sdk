/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_watchrunstate_free: (a: number, b: number) => void;
export const run_terminal_metadata: () => [number, number, number, number];
export const runtime_encode: (a: number, b: number, c: any) => [number, number, number];
export const runtime_shape_error: (a: number, b: number, c: any) => [number, number];
export const schema_error: (a: number, b: number, c: number, d: number) => [number, number];
export const validate_customer_wire: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number];
export const watch_run_start_state_wire: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
export const watch_run_start_wire: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
export const watchrunstate_advance: (a: number, b: number, c: number) => [number, number];
export const watchrunstate_finish: (a: number) => [number, number];
export const watchrunstate_terminal: (a: number) => number;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
