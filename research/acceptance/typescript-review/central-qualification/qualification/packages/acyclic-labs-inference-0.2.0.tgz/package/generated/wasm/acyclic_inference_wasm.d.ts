/* tslint:disable */
/* eslint-disable */

/**
 * Opaque Rust-owned state for an ordered Run watch.
 */
export class WatchRunState {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Validate one protobuf Run event and advance this state in place.
     */
    advance(event: Uint8Array): void;
    /**
     * Confirm that the stream ended after a terminal event.
     */
    finish(): void;
    /**
     * Whether a terminal event has already been consumed.
     */
    readonly terminal: boolean;
}

/**
 * Return the terminal metadata declared by the protobuf enum options.
 *
 * The browser-facing package consumes this small boundary instead of
 * reimplementing enum naming or deciding which terminal outcomes may carry
 * incomplete output. The descriptor is the same generated descriptor used
 * by schema validation, so adding or renaming a terminal must update the
 * protobuf contract before it can reach TypeScript.
 */
export function run_terminal_metadata(): string;

/**
 * Encode a JavaScript protobuf-shaped value using the Rust descriptor and
 * canonical dynamic message encoder. Shape validation and protobuf encoding
 * therefore share one reflection boundary instead of relying on a TypeScript
 * cast followed by generated runtime coercion.
 */
export function runtime_encode(message_name: string, value: any): Uint8Array;

/**
 * Validate the JavaScript object shape before protobuf encoding can coerce it.
 */
export function runtime_shape_error(message_name: string, value: any): string | undefined;

/**
 * Validate a protobuf message by its fully-qualified descriptor name.
 * Returns a TypeScript-compatible diagnostic, or `None` when valid.
 */
export function schema_error(message_name: string, bytes: Uint8Array): string | undefined;

/**
 * Validate the exact generated message shape and caller-bound identity.
 * Byte arrays remain byte arrays across this boundary; no JSON or JS number
 * conversion is involved.
 */
export function validate_customer_wire(kind: string, message: Uint8Array, expected: Uint8Array, related: Uint8Array): void;

/**
 * Start Rust-owned state for a validated Run watch.
 */
export function watch_run_start_state_wire(message: Uint8Array, expected: Uint8Array, from_sequence: string): WatchRunState;

/**
 * Decide from a validated Run view whether watching at this cursor is already complete.
 */
export function watch_run_start_wire(message: Uint8Array, expected: Uint8Array, from_sequence: string): boolean;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_watchrunstate_free: (a: number, b: number) => void;
    readonly run_terminal_metadata: () => [number, number, number, number];
    readonly runtime_encode: (a: number, b: number, c: any) => [number, number, number];
    readonly runtime_shape_error: (a: number, b: number, c: any) => [number, number];
    readonly schema_error: (a: number, b: number, c: number, d: number) => [number, number];
    readonly validate_customer_wire: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number];
    readonly watch_run_start_state_wire: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly watch_run_start_wire: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly watchrunstate_advance: (a: number, b: number, c: number) => [number, number];
    readonly watchrunstate_finish: (a: number) => [number, number];
    readonly watchrunstate_terminal: (a: number) => number;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
