/* tslint:disable */
/* eslint-disable */

export class ObjectsV2Memory {
    free(): void;
    [Symbol.dispose](): void;
    invoke(route: string, bytes: Uint8Array, body: Uint8Array, maximum: bigint): Promise<Array<any>>;
    constructor(maximum_bytes: bigint, maximum_entries: number);
}

export function decode_objects_v2_json(name: string, bytes: Uint8Array, maximum: number): Uint8Array;

export function encode_objects_v2_json(name: string, bytes: Uint8Array, maximum: number): Uint8Array;

/**
 * Maps Connect/tonic status/detail values through the canonical Objects
 * error vocabulary before they cross the browser boundary.
 */
export function objects_v2_grpc_error_code(status: number, detail?: number | null): number;

/**
 * Returns the canonical decoded body bytes carried by one streaming frame.
 */
export function objects_v2_http_body_frame_bytes(): number;

/**
 * Maps hosted HTTP status/detail values through the canonical Objects error
 * vocabulary before they cross the browser boundary.
 */
export function objects_v2_http_error_code(status: number, detail?: number | null): number;

/**
 * Returns the canonical encoded JSON/NDJSON record limit used by Objects
 * native HTTP and browser framing.
 */
export function objects_v2_http_json_frame_bytes(): number;

export function objects_v2_http_type(route: string, output: boolean): string;

/**
 * Validates one bounded download body frame and returns its remaining range.
 */
export function validate_objects_v2_get_body(body_length: bigint, remaining: bigint): bigint;

export function validate_objects_v2_get_header(query: Uint8Array, bytes: Uint8Array, maximum: bigint): bigint;

/**
 * Validates the HTTPS or loopback HTTP endpoint policy used by native and
 * browser Objects clients.
 */
export function validate_objects_v2_http_endpoint(endpoint: string): void;

export function validate_objects_v2_request(route: string, bytes: Uint8Array, body_length: bigint): void;

export function validate_objects_v2_response(route: string, query: Uint8Array, bytes: Uint8Array, body_length: bigint): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_objectsv2memory_free: (a: number, b: number) => void;
    readonly decode_objects_v2_json: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly encode_objects_v2_json: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly objects_v2_grpc_error_code: (a: number, b: number) => number;
    readonly objects_v2_http_body_frame_bytes: () => number;
    readonly objects_v2_http_error_code: (a: number, b: number) => number;
    readonly objects_v2_http_json_frame_bytes: () => number;
    readonly objects_v2_http_type: (a: number, b: number, c: number) => [number, number, number, number];
    readonly objectsv2memory_invoke: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: bigint) => any;
    readonly objectsv2memory_new: (a: bigint, b: number) => [number, number, number];
    readonly validate_objects_v2_get_body: (a: bigint, b: bigint) => [bigint, number, number];
    readonly validate_objects_v2_get_header: (a: number, b: number, c: number, d: number, e: bigint) => [bigint, number, number];
    readonly validate_objects_v2_http_endpoint: (a: number, b: number) => [number, number];
    readonly validate_objects_v2_request: (a: number, b: number, c: number, d: number, e: bigint) => [number, number];
    readonly validate_objects_v2_response: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint) => [number, number];
    readonly wasm_bindgen_2db2d17d2c533688___convert__closures_____invoke___wasm_bindgen_2db2d17d2c533688___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_2db2d17d2c533688___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_2db2d17d2c533688___convert__closures_____invoke___js_sys_a5471da919551fc6___Function_fn_wasm_bindgen_2db2d17d2c533688___JsValue_____wasm_bindgen_2db2d17d2c533688___sys__Undefined___js_sys_a5471da919551fc6___Function_fn_wasm_bindgen_2db2d17d2c533688___JsValue_____wasm_bindgen_2db2d17d2c533688___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
