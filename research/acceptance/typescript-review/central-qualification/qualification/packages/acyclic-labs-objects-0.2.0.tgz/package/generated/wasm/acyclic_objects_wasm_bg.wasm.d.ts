/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_objectsv2memory_free: (a: number, b: number) => void;
export const decode_objects_v2_json: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
export const encode_objects_v2_json: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
export const objects_v2_grpc_error_code: (a: number, b: number) => number;
export const objects_v2_http_body_frame_bytes: () => number;
export const objects_v2_http_error_code: (a: number, b: number) => number;
export const objects_v2_http_json_frame_bytes: () => number;
export const objects_v2_http_type: (a: number, b: number, c: number) => [number, number, number, number];
export const objectsv2memory_invoke: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: bigint) => any;
export const objectsv2memory_new: (a: bigint, b: number) => [number, number, number];
export const validate_objects_v2_get_body: (a: bigint, b: bigint) => [bigint, number, number];
export const validate_objects_v2_get_header: (a: number, b: number, c: number, d: number, e: bigint) => [bigint, number, number];
export const validate_objects_v2_http_endpoint: (a: number, b: number) => [number, number];
export const validate_objects_v2_request: (a: number, b: number, c: number, d: number, e: bigint) => [number, number];
export const validate_objects_v2_response: (a: number, b: number, c: number, d: number, e: number, f: number, g: bigint) => [number, number];
export const wasm_bindgen_2db2d17d2c533688___convert__closures_____invoke___wasm_bindgen_2db2d17d2c533688___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_2db2d17d2c533688___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_2db2d17d2c533688___convert__closures_____invoke___js_sys_a5471da919551fc6___Function_fn_wasm_bindgen_2db2d17d2c533688___JsValue_____wasm_bindgen_2db2d17d2c533688___sys__Undefined___js_sys_a5471da919551fc6___Function_fn_wasm_bindgen_2db2d17d2c533688___JsValue_____wasm_bindgen_2db2d17d2c533688___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
