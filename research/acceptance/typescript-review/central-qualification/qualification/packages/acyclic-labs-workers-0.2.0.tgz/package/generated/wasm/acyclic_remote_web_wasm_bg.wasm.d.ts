/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const validate_actors_invoke: (a: number, b: number, c: number, d: number) => [number, number];
export const validate_remote_web_ca_certificate: (a: number, b: number) => [number, number];
export const validate_remote_web_content_length: (a: number, b: number, c: bigint) => [number, number];
export const validate_remote_web_credential: (a: number, b: number) => [number, number];
export const validate_remote_web_endpoint: (a: number, b: number) => [number, number];
export const validate_remote_web_grpc_endpoint: (a: number, b: number) => [number, number];
export const validate_remote_web_message_limit: (a: bigint) => [number, number];
export const validate_remote_web_response_chunk: (a: bigint, b: bigint, c: bigint) => [bigint, number, number];
export const validate_remote_web_response_limit: (a: bigint) => [number, number];
export const validate_workers_invoke_deployment: (a: number, b: number, c: number, d: number) => [number, number];
export const validate_workers_invoke_version: (a: number, b: number, c: number, d: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
