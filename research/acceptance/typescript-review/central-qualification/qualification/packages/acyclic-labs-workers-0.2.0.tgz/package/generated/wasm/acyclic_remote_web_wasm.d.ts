/* tslint:disable */
/* eslint-disable */

/**
 * Validates the Rust Actors invoke request admission rules.
 */
export function validate_actors_invoke(actor_id: string, method: string): void;

/**
 * Validates the optional native TLS CA certificate before it reaches the
 * platform gRPC adapter.
 */
export function validate_remote_web_ca_certificate(certificate: string): void;

/**
 * Checks an HTTP content-length without first narrowing it through a JS number.
 */
export function validate_remote_web_content_length(content_length: string, maximum: bigint): void;

/**
 * Validates one bearer credential according to the shared Rust policy.
 */
export function validate_remote_web_credential(token: string): void;

/**
 * Validates the HTTPS or loopback-HTTP endpoint shared by Actors and Workers.
 */
export function validate_remote_web_endpoint(endpoint: string): void;

/**
 * Validates the HTTPS endpoint required by native gRPC transports.
 */
export function validate_remote_web_grpc_endpoint(endpoint: string): void;

/**
 * Validates the configured native gRPC message bound.
 */
export function validate_remote_web_message_limit(maximum: bigint): void;

/**
 * Advances a cumulative response byte count under the caller's configured bound.
 */
export function validate_remote_web_response_chunk(observed: bigint, chunk: bigint, maximum: bigint): bigint;

/**
 * Validates the configured cumulative response bound.
 */
export function validate_remote_web_response_limit(maximum: bigint): void;

/**
 * Validates the Rust Workers invoke-deployment path and request admission rules.
 */
export function validate_workers_invoke_deployment(alias: string, method: string): void;

/**
 * Validates the Rust Workers invoke-version path and request admission rules.
 */
export function validate_workers_invoke_version(version_sha256: Uint8Array, method: string): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly validate_actors_invoke: (a: number, b: number, c: number, d: number) => [number, number];
    readonly validate_remote_web_ca_certificate: (a: number, b: number) => [number, number];
    readonly validate_remote_web_content_length: (a: number, b: number, c: bigint) => [number, number];
    readonly validate_remote_web_credential: (a: number, b: number) => [number, number];
    readonly validate_remote_web_endpoint: (a: number, b: number) => [number, number];
    readonly validate_remote_web_grpc_endpoint: (a: number, b: number) => [number, number];
    readonly validate_remote_web_message_limit: (a: bigint) => [number, number];
    readonly validate_remote_web_response_chunk: (a: bigint, b: bigint, c: bigint) => [bigint, number, number];
    readonly validate_remote_web_response_limit: (a: bigint) => [number, number];
    readonly validate_workers_invoke_deployment: (a: number, b: number, c: number, d: number) => [number, number];
    readonly validate_workers_invoke_version: (a: number, b: number, c: number, d: number) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
