const mod=require('./node_modules/@acyclic-labs/fs-win32-x64/index.node'); console.log(Object.keys(mod)); console.log(mod.nativeCapabilities());
