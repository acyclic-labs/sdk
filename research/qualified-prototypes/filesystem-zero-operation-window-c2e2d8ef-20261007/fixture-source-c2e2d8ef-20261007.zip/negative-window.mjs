import initialize, { openBrowserFs } from "/generated/wasm/acyclic_fs_wasm.js";
import { DEFAULT_OBJECT_CACHE_OPTIONS } from "/generated/defaults.js";
import { adaptWasmFs, adaptWasmOperationWindows } from "/dist/wasm-adapter.js";
const result = document.querySelector("#result");
const fail = error => { result.dataset.status = "failed"; result.textContent = String(error?.stack ?? error); };
try {
  await initialize();
  const raw = await openBrowserFs({
    databaseName: `negative-${crypto.randomUUID()}`,
    maximumObjectBytes: 64 * 1024 * 1024,
    objectAcceleration: "indexeddb",
    objectCache: DEFAULT_OBJECT_CACHE_OPTIONS,
  });
  const fs = adaptWasmFs(raw);
  try {
    const windows = adaptWasmOperationWindows(fs);
    const fields = ["maximumGenerations", "maximumChanges", "maximumConflicts"];
    for (const field of fields) {
      const parent = await fs.createWorkspace(`parent-${field}`);
      const child = await parent.fork(`child-${field}`);
      const parentHead = await parent.head();
      const lease = await windows.begin(child.id, parentHead, "negative-fixture", 1n, 20n);
      const options = {
        maximumGenerations: field === "maximumGenerations" ? 0 : 16,
        maximumChanges: field === "maximumChanges" ? 0 : 16,
        maximumConflicts: field === "maximumConflicts" ? 0 : 16,
      };
      let finishError;
      try { await windows.finishWorkspace(child, lease, 2n, options); }
      catch (error) { finishError = String(error?.message ?? error); }
      const afterFinish = await windows.inspect(child.id);
      let recoverError;
      try { await windows.recoverWorkspace(child, 20n, options); }
      catch (error) { recoverError = String(error?.message ?? error); }
      const afterRecover = await windows.inspect(child.id);
      if (!finishError?.includes("workspace join exceeds its configured bound") || !recoverError?.includes("workspace join exceeds its configured bound")) throw new Error(`${field}: unexpected errors finish=${finishError} recover=${recoverError}`);
      if (afterFinish.kind !== "active" || afterFinish.activeLeaseCount !== 1) throw new Error(`${field}: finish changed phase ${JSON.stringify(afterFinish)}`);
      if (afterRecover.kind !== "active" || afterRecover.activeLeaseCount !== 1) throw new Error(`${field}: recovery claimed lease ${JSON.stringify(afterRecover)}`);
    }
    result.dataset.status = "passed";
    result.textContent = "WASM public adapter preserved the active lease for all three invalid zero limits and did not claim expired recovery.";
  } finally { fs.close(); }
} catch (error) { fail(error); }
