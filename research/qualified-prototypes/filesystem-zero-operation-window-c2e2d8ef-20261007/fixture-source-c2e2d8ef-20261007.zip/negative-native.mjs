import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
const native = await import(pathToFileURL(process.env.FS_DIST_NATIVE).href);
const contracts = await import(pathToFileURL(process.env.FS_DIST_CONTRACTS).href);
const { openNativeFs, openNativeOperationWindowCoordinator } = native;
const { DEFAULT_OBJECT_CACHE_OPTIONS } = contracts;
const fields = ["maximumGenerations", "maximumChanges", "maximumConflicts"];
const optionsFor = field => ({ maximumGenerations: field === "maximumGenerations" ? 0 : 16, maximumChanges: field === "maximumChanges" ? 0 : 16, maximumConflicts: field === "maximumConflicts" ? 0 : 16 });
const result = [];
const root = await mkdtemp(join(tmpdir(), "fs-op-window-native-"));
const fs = await openNativeFs({ root, objectCache: DEFAULT_OBJECT_CACHE_OPTIONS });
try {
  const windows = await openNativeOperationWindowCoordinator(fs);
  for (const field of fields) {
    const parent = await fs.createWorkspace(`parent-${field}`);
    const child = await parent.fork(`child-${field}`);
    const parentHead = await parent.head();
    const lease = await windows.begin(child.id, parentHead, "negative-fixture", 1n, 20n);
    const options = optionsFor(field);
    let finishError;
    try { await windows.finishWorkspace(child, lease, 2n, options); }
    catch (error) { finishError = String(error?.message ?? error); }
    const afterFinish = await windows.inspect(child.id);
    let recoverError;
    try { await windows.recoverWorkspace(child, 20n, options); }
    catch (error) { recoverError = String(error?.message ?? error); }
    const afterRecover = await windows.inspect(child.id);
    if (!finishError?.includes("workspace join exceeds its configured bound") || !recoverError?.includes("workspace join exceeds its configured bound")) throw new Error(`${field}: unexpected errors finish=${finishError} recover=${recoverError}`);
    if (afterFinish.kind !== "active" || afterFinish.activeLeaseCount !== 1) throw new Error(`${field}: finish changed phase ${JSON.stringify(afterFinish)}`);
    if (afterRecover.kind !== "active" || afterRecover.activeLeaseCount !== 1) throw new Error(`${field}: recovery claimed lease ${JSON.stringify(afterRecover)}`);
    result.push({ field, finishError, recoverError, afterFinish, afterRecover });
  }
} finally { fs.close(); }
console.log(JSON.stringify({ root, result }, null, 2));

