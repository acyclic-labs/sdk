import { pathToFileURL } from "node:url";
const packageShim = pathToFileURL(process.env.FS_FIXTURE_SHIM).href;
export async function resolve(specifier, context, nextResolve) {
  if (specifier === "@acyclic-labs/fs-win32-x64") return { url: packageShim, shortCircuit: true };
  return nextResolve(specifier, context);
}
