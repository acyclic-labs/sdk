import { pathToFileURL } from "node:url";
const packageShim = pathToFileURL(process.env.FS_FIXTURE_SHIM).href;
console.error("shim", process.env.FS_FIXTURE_SHIM, packageShim);
export async function resolve(specifier, context, nextResolve) {
  if (specifier === "@acyclic-labs/fs-win32-x64") { console.error("intercept", specifier, packageShim); return { url: packageShim, shortCircuit: true }; }
  return nextResolve(specifier, context);
}
