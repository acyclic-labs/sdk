import { pathToFileURL } from "node:url";
const u = pathToFileURL(process.env.FS_DIST_NATIVE).href;
console.log(process.platform, u);
await import(u);
console.log("ok");
